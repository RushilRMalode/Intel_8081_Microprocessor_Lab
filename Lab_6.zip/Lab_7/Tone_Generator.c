#include  <at89c5131.h>
sbit OP=P0^7;

int count=1;

void timer0_isr () interrupt 1
{
	OP=~OP;
	if(count<21)
	{
	TL0 = 0xB9; //Starting Count value
	TH0 = 0xEF;
	TR0 = 1; //Start indicates the counting starts
	}
	//Sa
	else if(count<51 && count>21)
	{
	TL0 = 0x88;
	TH0 = 0xF1;
	TR0 = 1;
	}	
	//Re
	else if(count >50 && count<91)
	{
	TL0 = 0xFB;
	TH0 = 0xF2;
	TR0 = 1;
	}
	//Ga end
	else if(count>90 && count<111)
	{
	TL0 = 0xCB;
	TH0 = 0xF3;
	TR0 = 1;
	}	
	//END MA
	else if(count>110 && count<151)
	{
	TL0 = 0x26;
	TH0 = 0xF5;
	TR0 = 1;
	}	
	//END PA
	else if(count>150 && count<181)
	{
	TL0 = 0x3C;
	TH0 = 0xF6;
	TR0 = 1;
	}		
	//END DHA
	else if(count>180 && count<221)
	{
	TL0 = 0x52;
	TH0 = 0xF7;
	TR0 = 1;
	}
	else if(count>220 && count<241)
	{
	TL0 = 0xDD;
	TH0 = 0xF7;
	TR0 = 1;
	}
	else if(count>240)
		count=1;
		
}

void timer1_isr () interrupt 3
{
  ++count;
	TH1=0x3C;//value for 25ms
	TL1=0xB0;
	TR1 = 1; //start timer 1
}

void main(void)
{
	TMOD=0x11;
	TH1=0x9E;
	TL1=0x58;
	TL0 = 0xB9; //Starting Count value
	TH0 = 0xEF;
	ET0 = 1; //activate interrupts for both timers
	ET1 = 1;
	EA = 1;  //activate global interrupts
	TR0 = 1; //start timer 0
	TR1 = 1; //start timer 1
	
	while(1);
	/*
	
	*/
}