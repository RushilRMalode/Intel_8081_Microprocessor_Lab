#include <at89c5131.h>
#include "lcd.h"

code unsigned char display_msg1[]="Input 1:";						//Display msg on 1st line of lcd
code unsigned char display_msg2[]="Input 2:";						//Display msg on 1st line of lcd
code unsigned char display_msg3[]="Prediction:";
code unsigned char display_msg4[]="Class 1";
code unsigned char display_msg5[]="Class 2";
code unsigned char display_msg6[]="           ";

void main()
{
	int w0=-36;
	int w1=5;
	int w2=7;
	int x1;
	int x2;
	int y;
	lcd_init();
	lcd_cmd(0x80);													//Move cursor to first line
	msdelay(4);
	lcd_write_string(display_msg1);
	P1=0x0F;
	msdelay(5000);
	x1=P1;
	msdelay(4);
	lcd_cmd(0xC5);
	msdelay(4);
	
	if(x1>=0 && x1<=9)
	{	
	lcd_write_char(x1+48);
	}
	else if(x1>9)
	{
	lcd_write_char(x1+55);
	}
	
	msdelay(2000);
	lcd_cmd(0x80);													//Move cursor to 1rst line of LCD
	lcd_write_string(display_msg2);
	P1=0x0F;
	msdelay(5000);
	x2=P1;
	lcd_cmd(0xC5);													//Move cursor to 2nd line of LCD
	msdelay(4);
	lcd_write_string(display_msg6);
	msdelay(4);
	lcd_cmd(0xC5);													//Move cursor to 2nd line of LCD
	msdelay(4);
	if(x2>=0 && x2<=9)
	{	
	lcd_write_char(x2+48);
	}
	else if(x2>9)
	{
	lcd_write_char(x2+55);
	}
	msdelay(2000);
	
	y=w0+(x1*w1)+(x2*w2);
	
	if(y>=0)
	{
		lcd_cmd(0x80);													//Move cursor to 1rst line of LCD
		msdelay(4);
		lcd_write_string(display_msg3);
		msdelay(4);
		lcd_cmd(0xC0);													//Move to 2nd line
		lcd_write_string(display_msg5);
	}
	else
	{
		lcd_cmd(0x80);													//Move cursor to 1rst line of LCD
		msdelay(4);
		lcd_write_string(display_msg3);
		msdelay(4);
		lcd_cmd(0xC0);													//Move to 2nd line
		lcd_write_string(display_msg4);
	}
	
	
	while(1);
		
}