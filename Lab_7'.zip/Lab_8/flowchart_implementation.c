#include  <at89c5131.h>
#include  "lcd.h"
sbit R1= P3^4;
sbit R2= P3^5;
sbit R3= P3^6;
sbit R4= P3^7;
sbit C1= P3^3;
sbit C2= P3^2;
sbit C3= P3^1;
sbit C4= P3^0;
sbit OP=P0^7;

code unsigned char display_msg1[]="NOTE PLAYED IS:";
int key=0;
void timer0_isr () interrupt 1
{
	OP=~OP;
	if(key==1)
	{
	TF0=0;
	TL0 = 0xB9; //Starting Count value
	TH0 = 0xEF;
	TR0 = 1;		//Start indicates the counting starts
	}
	//Sa
	else if(key==2)
	{
	TF0=0;	
	TL0 = 0x88;
	TH0 = 0xF1;
	TR0 = 1;
	}	
	//Re
	else if(key==3)
	{
	TF0=0;		
	TL0 = 0xFB;
	TH0 = 0xF2;
	TR0 = 1;
	}
	//Ga end
	else if(key==4)
	{
	TF0=0;		
	TL0 = 0xCB;
	TH0 = 0xF3;
	TR0 = 1;
	}	
	//END MA
	else if(key==5)
	{
	TF0=0;		
	TL0 = 0x26;
	TH0 = 0xF5;
	TR0 = 1;
	}	
	//END PA
	else if(key==6)
	{
	TF0=0;	
	TL0 = 0x3C;
	TH0 = 0xF6;
	TR0 = 1;
	}		
	//END DHA
	else if(key==7)
	{
	TF0=0;		
	TL0 = 0x52;
	TH0 = 0xF7;
	TR0 = 1;
	}
	else if(key==8)
	{
	TF0=0;		
	TL0 = 0xDD;
	TH0 = 0xF7;
	TR0 = 1;
	}
	else if((key==9)||(key==11)||(key==12)||(key==13)||(key==14)||(key==0))
	{
	TH0=0;
	TL0=0;	
	TF0=0;	
	}
}


void main(void)
{
	lcd_init();
	lcd_cmd(0x80);													//Move cursor to first line
	msdelay(4);
	lcd_write_string(display_msg1);
	TMOD=0x11;
	TL0 = 0xB9; //Starting Count value
	TH0 = 0xEF;
	ET0 = 1; //activate interrupt
	EA = 1;  //activate global interrupts
	TR0 = 1; //start timer 0
	
	while(1)
	{
	P3=0x0F;
	zeroer:	R1=0;
					R2=0;
					R3=0;
					R4=0;

	if((C1 && C2 && C3 && C4)==1)
		goto keychecker;
	else
		goto zeroer;
	keychecker:	
		if((C1 && C2 && C3 && C4)==0)	
		msdelay(20);
		else
		goto keychecker;

	  if((C1 && C2 && C3 && C4)==0)	
			goto row1_zero;
		else
		goto keychecker;
		
		row1_zero: 
					R1=0;
					R2=1;
					R3=1;
					R4=1;
		
		if((C1 && C2 && C3 && C4)==0)
		{
			if(C1==0)
				key=1;
			else if(C2==0)
				key=2;
			else if(C3==0)
				key=3;
			else if(C4==0)
				key=11;
		goto LCD;
		}
		else
			goto row2_zero;
		row2_zero:
					R1=1;
					R2=0;
					R3=1;
					R4=1;
	
		if((C1 && C2 && C3 && C4)==0)
		{
			if(C1==0)
				key=4;
			else if(C2==0)
				key=5;
			else if(C3==0)
				key=6;
			else if(C4==0)
				key=12;
			goto LCD;
		}
		else
			goto row3_zero;
		row3_zero:
					R1=1;
					R2=1;
					R3=0;
					R4=1;

		if((C1 && C2 && C3 && C4)==0)
		{
			if(C1==0)
				key=7;
			else if(C2==0)
				key=8;
			else if(C3==0)
				key=9;
			else if(C4==0)
				key=13;
			goto LCD;
		}
		else
			goto row4_zero;
		row4_zero:
					R1=1;
					R2=1;
					R3=1;
					R4=0;

		if((C1 && C2 && C3 && C4)==0)
		{
			if(C1==0)
				key=16;
			else if(C2==0)
				key=0;
			else if(C3==0)
				key=17;
			else if(C4==0)
				key=14;
		}
		LCD:
    	msdelay(4);
			lcd_cmd(0xC5);
			msdelay(4);
			lcd_write_string("        ");
			msdelay(4);
			lcd_cmd(0xC5);
			msdelay(4);
			if(key==1)
			lcd_write_string("SA");
			if(key==2)
			lcd_write_string("RE");
			if(key==3)
			lcd_write_string("GA");
			if(key==4)
			lcd_write_string("MA");
			if(key==5)
			lcd_write_string("PA");
			if(key==6)
			lcd_write_string("DHA");
			if(key==7)
			lcd_write_string("NI");
			if(key==8)
			lcd_write_string("SA*");
			if((key==9)||(key==11)||(key==12)||(key==13)||(key==14)||(key==0))
			lcd_write_string("SILENCE");
	}
}